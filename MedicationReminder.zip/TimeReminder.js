//TimeReminder
import React, { useState, useRef, useEffect } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, TextInput, Platform } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Modalize } from 'react-native-modalize';
import { Picker } from '@react-native-picker/picker'; // สำหรับ iOS และ Android

const TimeReminder = ({ route }) => {
  const { selectedDay } = route.params || {};
  const navigation = useNavigation();
  const [medicationName, setMedicationName] = useState('');
  const [frequency, setFrequency] = useState('as_needed');
  const [selectedHour, setSelectedHour] = useState('8'); // ค่าเริ่มต้น
  const [selectedMinute, setSelectedMinute] = useState('00'); // ค่าเริ่มต้น
  const [selectedAMPM, setSelectedAMPM] = useState('AM'); // ค่าเริ่มต้น
  const [specificDays, setSpecificDays] = useState([]);
  const [menstrualCycleOption, setMenstrualCycleOption] = useState(null);
  const [timeSummary, setTimeSummary] = useState('Select Time');
  const [isSaveButtonEnabled, setIsSaveButtonEnabled] = useState(false); // State สำหรับควบคุมปุ่ม Save

  const frequencyModal = useRef(null);
  const timePickerModal = useRef(null);
  const menstrualCycleModal = useRef(null);

  const hours = Array.from({ length: 12 }, (_, i) => String(i + 1)); // 1-12
  const minutes = Array.from({ length: 60 }, (_, i) => String(i).padStart(2, '0')); // 00-59
  const ampmOptions = ['AM', 'PM'];
  const daysOfWeek = ['s', 'm', 't', 'w', 't', 'f', 's'];
  const frequencyOptions = [
    { label: 'Daily', value: 'daily' },
    { label: 'Specific Days', value: 'specific_day' },
    { label: 'Menstrual Cycle', value: 'menstrual_cycle' },
    { label: 'As Needed', value: 'as_needed' },
  ];
  const menstrualCycleOptions = [
    { label: '21 take, 7 break', value: '21take_7break' },
    { label: '22 take, 6 break', value: '22take_6break' },
    { label: '23 take, 4 break', value: '23take_4break' },
    { label: '24 take, 4 break', value: '24take_4break' },
    { label: '26 take, 2 break', value: '26take_2break' },
    { label: '28 take', value: '28take' },
  ];

  useEffect(() => {
    // เงื่อนไข: ต้องมีการเลือกเวลาแล้ว (ไม่ใช่ค่าเริ่มต้น 'Select Time')
    const isTimeSelected = timeSummary !== 'Select Time';
    setIsSaveButtonEnabled(isTimeSelected);
  }, [timeSummary]);

  const handleGoBack = () => {
    navigation.goBack();
  };

  const handleFrequencyPress = () => {
    frequencyModal.current?.open();
  };

  const handleTimePickerPress = () => {
    timePickerModal.current?.open();
  };

  const handleNextPress = () => {
    if (isSaveButtonEnabled) {
      console.log('Next pressed - Save reminder and navigate');
      console.log('Selected Day:', selectedDay);
      console.log('Medication Name:', medicationName);
      console.log('Frequency:', frequency);
      console.log('Selected Time:', `${selectedHour}:${selectedMinute} ${selectedAMPM}`);

      const newMedication = {
        time: `${selectedHour}:${selectedMinute} ${selectedAMPM}`,
        name: medicationName || 'No Name',
        day: selectedDay,
        // คุณสามารถเพิ่มข้อมูลความถี่ หรืออื่นๆ ที่ต้องการบันทึกได้ที่นี่
      };

      // นำข้อมูลที่บันทึกใหม่นี้ ส่งกลับไปยังหน้า MedTime
      navigation.navigate('MedTime', { newMedication });
    } else {
      // แสดงข้อความแจ้งเตือนให้เลือกเวลา (optional)
      console.log('Please select time to save.');
    }
  };

  const DayCircle = ({ day, index, isSelected, onPress }) => (
    <TouchableOpacity
      style={[
        styles.dayCircle,
        isSelected && styles.selectedDayCircle,
      ]}
      onPress={onPress}
    >
      <Text style={[styles.dayText, isSelected && styles.selectedDayText]}>{day.toUpperCase()}</Text>
    </TouchableOpacity>
  );

  const updateTimeSummary = (hour, minute, ampm) => {
    setTimeSummary(`${hour}:${minute} ${ampm}`);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Add Reminder</Text>
        <TouchableOpacity onPress={handleGoBack}>
          <Text style={styles.headerBackButton}>X</Text>
        </TouchableOpacity>
      </View>

      {/* Input Fields */}
      <View style={styles.inputContainer}>
        <Text style={styles.inputLabel}>Medication Name</Text>
        <TextInput
          style={styles.input}
          value={medicationName}
          onChangeText={setMedicationName}
          placeholder="Enter medication name"
        />
      </View>

      {/* Frequency Picker */}
      <TouchableOpacity style={styles.button} onPress={handleFrequencyPress}>
        <Text style={styles.buttonLabel}>Frequency</Text>
        <View style={styles.buttonValueContainer}>
          <Text style={styles.buttonValue}>
            {frequencyOptions.find(option => option.value === frequency)?.label || 'Select Frequency'}
          </Text>
        </View>
      </TouchableOpacity>

      {/* Time Picker Button */}
      <TouchableOpacity style={styles.button} onPress={handleTimePickerPress}>
        <Text style={styles.buttonLabel}>Select Time</Text>
        <View style={styles.buttonValueContainer}>
          <Text style={styles.buttonValue}>{timeSummary}</Text>
        </View>
      </TouchableOpacity>

      {/* Additional Frequency Options UI */}
      {frequency === 'specific_day' && (
        <View style={styles.additionalOptions}>
          <Text style={styles.inputLabel}>Select Specific Days</Text>
          <View style={styles.daysOfWeekContainer}>
            {daysOfWeek.map((day, index) => (
              <DayCircle
                key={index}
                index={index}
                day={day}
                isSelected={specificDays.includes(index)}
                onPress={() => {
                  const updatedSpecificDays = [...specificDays];
                  const dayIndex = updatedSpecificDays.indexOf(index);
                  if (dayIndex > -1) {
                    updatedSpecificDays.splice(dayIndex, 1);
                  } else {
                    updatedSpecificDays.push(index);
                  }
                  setSpecificDays(updatedSpecificDays);
                }}
              />
            ))}
          </View>
        </View>
      )}

      {frequency === 'menstrual_cycle' && (
        <TouchableOpacity style={styles.button} onPress={() => menstrualCycleModal.current?.open()}>
          <Text style={styles.buttonLabel}>Menstrual Cycle</Text>
          <View style={styles.buttonValueContainer}>
            <Text style={styles.buttonValue}>
              {menstrualCycleOptions.find(option => option.value === menstrualCycleOption)?.label || 'Select Cycle'}
            </Text>
          </View>
        </TouchableOpacity>
      )}

      {/* Next Button */}
      <TouchableOpacity
        style={[styles.nextButton, { backgroundColor: isSaveButtonEnabled ? '#90ee90' : '#d3d3d3' }]}
        onPress={handleNextPress}
        disabled={!isSaveButtonEnabled}
      >
        <Text style={[styles.nextButtonText, { color: isSaveButtonEnabled ? '#333' : '#fff' }]}>Save</Text>
      </TouchableOpacity>

      {/* Frequency Modal */}
      <Modalize
        ref={frequencyModal}
        snapPoint={200}
        modalHeight={300}
      >
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Frequency</Text>
          {frequencyOptions.map((option) => (
            <TouchableOpacity
              key={option.value}
              style={styles.modalOption}
              onPress={() => {
                setFrequency(option.value);
                frequencyModal.current?.close();
              }}
            >
              <Text style={styles.modalOptionText}>{option.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </Modalize>

      {/* Time Picker Modal */}
      <Modalize
        ref={timePickerModal}
        snapPoint={300}
        modalHeight={400}
      >
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Select Time</Text>
          <View style={styles.timePickerContainerModal}>
            <View style={styles.pickerWrapperModal}>
              <Picker
                selectedValue={selectedHour}
                style={styles.timePickerModal}
                itemStyle={styles.timePickerItemModal}
                onValueChange={(itemValue) => setSelectedHour(itemValue)}
              >
                {hours.map((hour) => (
                  <Picker.Item key={hour} label={hour} value={hour} />
                ))}
              </Picker>
              <Text style={styles.pickerSeparatorModal}>:</Text>
              <Picker
                selectedValue={selectedMinute}
                style={styles.timePickerModal}
                itemStyle={styles.timePickerItemModal}
                onValueChange={(itemValue) => setSelectedMinute(itemValue)}
              >
                {minutes.map((minute) => (
                  <Picker.Item key={minute} label={minute} value={minute} />
                ))}
              </Picker>
              <Picker
                selectedValue={selectedAMPM}
                style={styles.ampmPickerModal}
                itemStyle={styles.ampmPickerItemModal}
                onValueChange={(itemValue) => setSelectedAMPM(itemValue)}
              >
                {ampmOptions.map((ampm) => (
                  <Picker.Item key={ampm} label={ampm} value={ampm} />
                ))}
              </Picker>
            </View>
            <Text style={styles.timeSummaryText}>Selected Time: {`${selectedHour}:${selectedMinute} ${selectedAMPM}`}</Text>
            <TouchableOpacity
              style={styles.confirmButton}
              onPress={() => {
                updateTimeSummary(selectedHour, selectedMinute, selectedAMPM);
                timePickerModal.current?.close();
              }}
            >
              <Text style={styles.confirmButtonText}>Confirm Time</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modalize>

      {/* Menstrual Cycle Modal */}
      <Modalize
        ref={menstrualCycleModal}
        snapPoint={200}
        modalHeight={350}
      >
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Menstrual Cycle</Text>
          {menstrualCycleOptions.map((option) => (
            <TouchableOpacity
              key={option.value}
              style={styles.modalOption}
              onPress={() => {
                setMenstrualCycleOption(option.value);
                menstrualCycleModal.current?.close();
              }}
            >
              <Text style={styles.modalOptionText}>{option.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </Modalize>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f8ff',
    padding: 20,
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginBottom: 30,
    width: '100%',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    textAlign: 'center',
  },
  headerBackButton: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'red',
  },
  inputContainer: {
    marginBottom: 20,
    width: '100%',
  },
  inputLabel: {
    fontSize: 16,
    color: '#555',
    marginBottom: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: 'white',
  },
  button: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 15,
    marginBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
    width: '100%',
  },
  buttonLabel: {
    fontSize: 16,
    color: '#333',
  },
  buttonValueContainer: {
    backgroundColor: '#e0f2f7',
    borderRadius: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  buttonValue: {
    fontSize: 16,
    color: '#555',
  },
  nextButton: {
    backgroundColor: '#90ee90',
    borderRadius: 8,
    padding: 15,
    alignItems: 'center',
    width: '100%',
  },
  nextButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  additionalOptions: {
    width: '100%',
    marginBottom: 20,
  },
  modalContent: {
    padding: 20,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  modalOption: {
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  modalOptionText: {
    fontSize: 16,
  },
  daysOfWeekContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 10,
  },
  dayCircle: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#e0f2f7',
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedDayCircle: {
    backgroundColor: '#90ee90',
  },
  dayText: {
    fontSize: 16,
    color: '#555',
  },
  selectedDayText: {
    color: 'white',
  },
  timePickerContainerModal: {
    alignItems: 'center',
  },
  pickerWrapperModal: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '80%',
    marginBottom: 20,
  },
  timePickerModal: {
    width: 80,
    height: 120,
  },
  timePickerItemModal: {
    fontSize: 24,
  },
  pickerSeparatorModal: {
    fontSize: 24,
    marginHorizontal: 10,
  },
  ampmPickerModal: {
    width: 80,
    height: 120,
  },
  ampmPickerItemModal: {
    fontSize: 24,
  },
  confirmButton: {
    backgroundColor: '#90ee90',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 20,
    alignItems: 'center',
    marginTop: 15,
  },
  confirmButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  timeSummaryText: {
    fontSize: 16,
    color: '#555',
    marginBottom: 10,
  },
});

export default TimeReminder;