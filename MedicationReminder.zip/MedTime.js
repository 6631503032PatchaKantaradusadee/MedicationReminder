//MedTime
import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ScrollView, Image } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';

const MedTime = ({ route }) => {
  const { profileIndex: initialProfileIndex, newMedication } = route.params || {};
  const navigation = useNavigation();
  const [selectedDay, setSelectedDay] = useState('Sunday');
  const [currentDayIndex, setCurrentDayIndex] = useState(new Date().getDay());
  const [medications, setMedications] = useState([]);
  const [activeTab, setActiveTab] = useState('Time');
  const [profileIndex, setProfileIndex] = useState(initialProfileIndex !== undefined ? initialProfileIndex : 0); // กำหนดค่าเริ่มต้น

  const profiles = [
    require('./assets/pm1.jpg'),
    require('./assets/pm2.jpg'),
    require('./assets/pm3.jpg'),
    require('./assets/pm4.jpg'),
    require('./assets/pm5.jpg'),
    require('./assets/pm6.png'),
  ];
  const selectedProfileImage = profiles[profileIndex];

  const daysOfWeekFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const daysOfWeekShort = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  const handleAddMedication = () => {
    if (selectedDay) {
      console.log(`Navigate to TimeReminder for day: ${selectedDay}`);
      navigation.navigate('TimeReminder', { selectedDay });
    } else {
      alert('Please select a day before adding a reminder.');
    }
  };

  const handleDayPress = (dayFull) => {
    if (dayFull === selectedDay) {
      console.log(`Deselected day: ${dayFull}`);
      setSelectedDay(null);
    } else {
      console.log(`Selected day: ${dayFull}`);
      setSelectedDay(dayFull);
    }
  };

  const handleTimePress = () => {
    setActiveTab('Time');
    console.log('Go to Time screen');
  };

  const handleProfileIconPress = () => {
    console.log('Profile icon pressed - Go to Profile screen');
    navigation.navigate('Profile'); // เปลี่ยนตรงนี้
    setActiveTab('ProfileIcon');
  };

  const handleSettingPress = () => {
    setActiveTab('Setting');
    console.log('Go to Setting screen');
    navigation.navigate('Setting');
  };

  useEffect(() => {
    setCurrentDayIndex(new Date().getDay());
    if (initialProfileIndex !== undefined) {
      setProfileIndex(initialProfileIndex);
    }
  }, [initialProfileIndex]);

  useEffect(() => {
    if (newMedication) {
      setMedications(prevMedications => {
        const updatedMedications = [...prevMedications, newMedication];
        // กรอง medications ตามวันที่ปัจจุบัน
        return updatedMedications.filter(med => {
          const currentDayFullName = daysOfWeekFull[currentDayIndex];
          if (med.frequency === 'daily') {
            return true;
          } else if (med.frequency === 'specific_day' && med.specificDays) {
            const selectedDaysFull = med.specificDays.map(index => daysOfWeekFull[index]);
            return selectedDaysFull.includes(currentDayFullName);
          } else if (!med.frequency) { // กรณีที่ไม่ได้ระบุความถี่ (อาจเป็นการเพิ่มแบบครั้งเดียว)
            // ในกรณีนี้ เราจะถือว่าให้แสดงในวันที่เพิ่มเท่านั้น
            // คุณอาจต้องส่งข้อมูลวันที่บันทึกจาก TimeReminder ด้วย
            // หากไม่มีวันที่บันทึก จะไม่แสดง
            return true; // ปรับ logic ตามความต้องการ
          }
          return false;
        });
      });
    }
  }, [newMedication, currentDayIndex]);

  const handleDeleteMedication = (indexToDelete) => {
    setMedications(prevMedications =>
      prevMedications.filter((_, index) => index !== indexToDelete)
    );
  };

  const renderMedicationItem = (med, index) => {
    let additionalInfo = '';
    if (med.frequency === 'specific_day' && med.specificDays && med.specificDays.length > 0) {
      const selectedDays = med.specificDays.map(dayIndex => daysOfWeekShort[dayIndex]).join(', ');
      additionalInfo = ` (${selectedDays})`;
    }

    return (
      <View key={index} style={styles.medicationItem}>
        <View style={styles.medicationInfo}>
          <Text style={styles.medicationTime}>{med.time}</Text>
          <Text style={styles.medicationName}>{med.name}{additionalInfo}</Text>
        </View>
        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() => handleDeleteMedication(index)}
        >
          <Text style={styles.deleteButtonText}>X</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.welcomeText}>Welcome</Text>
        <Text style={styles.timeReminderText}>Time reminder</Text>
      </View>

      <View style={styles.calendar}>
        {daysOfWeekShort.map((dayShort, index) => (
          <TouchableOpacity
            key={index}
            style={[
              styles.dayButtonContainer,
              selectedDay === daysOfWeekFull[index] && styles.selectedDayButtonActive,
            ]}
            onPress={() => handleDayPress(daysOfWeekFull[index])}
          >
            <Text style={styles.dayText}>{dayShort}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.medicationList}>
        <TouchableOpacity
          style={[styles.addMedicationItem, !selectedDay && styles.addMedicationItemDisabled]}
          onPress={handleAddMedication}
          disabled={!selectedDay}
        >
          <Text style={styles.addMedicationPlus}>+</Text>
        </TouchableOpacity>
        {medications.map(renderMedicationItem)}
      </ScrollView>

      <View style={styles.bottomNavigation}>
        <TouchableOpacity style={styles.navItem} onPress={handleTimePress}>
          <Text style={styles.navText}>Time</Text>
          {activeTab === 'Time' && <View style={styles.activeTabIndicator} />}
        </TouchableOpacity>
        {selectedProfileImage && (
          <TouchableOpacity style={styles.profileIconContainerLarge} onPress={handleProfileIconPress}>
            <Image source={selectedProfileImage} style={styles.profileIconLarge} resizeMode="cover" />
          </TouchableOpacity>
        )}
        <TouchableOpacity style={styles.navItem} onPress={handleSettingPress}>
          <Text style={styles.navText}>Setting</Text>
          {activeTab === 'Setting' && <View style={styles.activeTabIndicator} />}
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f8ff',
    paddingBottom: 80,
    paddingTop: 20,
  },
  headerContainer: {
    marginTop: 20,
    marginBottom: 20,
    paddingHorizontal: 20,
    alignItems: 'flex-start',
    zIndex: 1,
  },
  welcomeText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  timeReminderText: {
    fontSize: 18,
    color: '#555',
  },
  calendar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  dayButtonContainer: {
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedDayButtonActive: {
    backgroundColor: '#90ee90',
  },
  dayText: {
    fontSize: 16,
    color: '#555',
  },
  medicationList: {
    flexGrow: 1,
    paddingHorizontal: 20,
  },
  medicationItem: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  medicationInfo: {
    flex: 1,
  },
  medicationTime: {
    fontSize: 16,
    color: '#333',
    fontWeight: 'bold',
    marginBottom: 3,
  },
  medicationName: {
    fontSize: 16,
    color: '#555',
  },
  deleteButton: {
    backgroundColor: 'red',
    borderRadius: 15,
    width: 30,
    height: 30,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 10,
  },
  deleteButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  addMedicationItem: {
    borderWidth: 2,
    borderColor: '#90ee90',
    padding: 20,
    borderRadius: 10,
    marginBottom: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  addMedicationItemDisabled: {
    borderColor: '#ccc',
  },
  addMedicationPlus: {
    color: '#555',
    fontSize: 36,
    fontWeight: 'bold',
  },
  bottomNavigation: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#eee',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    height: 80,
    paddingHorizontal: 20,
  },
  navItem: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 5,
  },
  navText: {
    fontSize: 16,
    color: '#555',
  },
  profileIconContainerLarge: {
    width: 60,
    height: 60,
    borderRadius: 30,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: '#008000',
    borderWidth: 3,
  },
  profileIconLarge: {
    width: '100%',
    height: '100%',
  },
  activeTabIndicator: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: '#90ee90',
  },
});

export default MedTime;