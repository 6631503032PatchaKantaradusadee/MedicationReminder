import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Image,
  ActivityIndicator,
  Text,
  TouchableOpacity, // นำเข้า TouchableOpacity สำหรับสร้างปุ่ม
  ImageBackground, // นำเข้า ImageBackground
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

const Homepage = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [showButton, setShowButton] = useState(false); // สถานะเพื่อควบคุมการแสดงปุ่ม
  const navigation = useNavigation();

  useEffect(() => {
    // จำลองการโหลดข้อมูล (เช่น API request)
    const timer = setTimeout(() => {
      setIsLoading(false);
      setShowButton(true); // เมื่อโหลดเสร็จ ให้แสดงปุ่ม Login
    }, 3000); // กำหนดเวลาโหลด (3 วินาที)

    // ทำความสะอาด Timer เมื่อ Component ถูก Unmount
    return () => clearTimeout(timer);
  }, []); // ไม่ต้องมี navigation ใน Dependency Array เพราะเรา Navigate เมื่อกดปุ่ม

  const handleLoginButtonPress = () => {
    navigation.navigate('Login'); // นำทางไปยังหน้า LoginScreen
  };

  if (isLoading) {
    return (
      <ImageBackground source={require('./assets/bg_med.jpg')} style={styles.background}>
        <View style={styles.loadingContainer}>
          <Text style={styles.logoText}>Medication Reminder App</Text> {/* ข้อความบนโลโก้ */}
          <View style={styles.imageContainer}>
            <Image
              source={require('./assets/logo_med.jpg')}
              style={styles.splashImage}
              resizeMode="cover"
            />
          </View>
          <ActivityIndicator size="large" color="#90EE90" style={styles.loadingIndicator} />
          <Text style={styles.loadingText}>Loading ...</Text>
        </View>
      </ImageBackground>
    );
  }

  return (
    <ImageBackground source={require('./assets/bg_med.jpg')} style={styles.background}>
      <View style={styles.loadedContainer}>
        <Text style={styles.logoText}>Medication Reminder App</Text> {/* ข้อความบนโลโก้ */}
        <View style={styles.imageContainer}>
          <Image
            source={require('./assets/logo_med.jpg')}
            style={styles.splashImage}
            resizeMode="cover"
          />
        </View>
        {showButton && (
          <View style={styles.buttonContainer}> {/* เพิ่ม container สำหรับจัดกลุ่มปุ่ม */}
            <TouchableOpacity style={styles.loginButton} onPress={handleLoginButtonPress}>
              <Text style={styles.loginButtonText}>Login</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadedContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoText: {
    fontSize: 24, // ปรับขนาดตัวอักษรจาก 18 เป็น 24 (หรือค่าที่คุณต้องการ)
    fontWeight: 'bold',
    color: '#333333',
    textAlign: 'center',
    marginBottom: 50,
  },
  imageContainer: {
    width: 200,
    height: 200,
    borderRadius: 100,
    overflow: 'hidden',
    marginBottom: 30,
  },
  splashImage: {
    width: '100%',
    height: '100%',
  },
  loadingIndicator: {
    marginTop: 10,
  },
  loadingText: {
    marginTop: 10,
    color: '#333333',
  },
  buttonContainer: {  // style สำหรับ container ของปุ่ม
    alignItems: 'center', // จัดปุ่มให้อยู่ตรงกลางตามแนวนอน
  },
  loginButton: {
    backgroundColor: '#90EE90',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 20,
    marginBottom: 10, // เพิ่มระยะห่างระหว่างปุ่ม
  },
  loginButtonText: {
    color: '#333333',
    fontSize: 18,
    fontWeight: 'bold',
  },
  // เราได้ลบ styles ของ guestButton และ guestButtonText ออกแล้ว
});

export default Homepage;