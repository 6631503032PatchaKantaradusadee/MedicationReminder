import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Image,
  TextInput,
  ScrollView,
  ImageBackground, // นำเข้า ImageBackground
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

const ProfileScreen = () => {
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [username, setUsername] = useState('');
  const navigation = useNavigation();

  const profiles = [
    require('./assets/pm1.jpg'), // แทนที่ด้วย Path รูปภาพจริงของคุณ
    require('./assets/pm2.jpg'),
    require('./assets/pm3.jpg'),
    require('./assets/pm4.jpg'),
    require('./assets/pm5.jpg'),
    require('./assets/pm6.png'),
  ];

  const isNextButtonEnabled = selectedProfile !== null && username.trim() !== '';

  const handleProfileSelect = (index) => {
    if (selectedProfile === index) {
      // ถ้ากดรูปที่เลือกอยู่แล้ว ให้ยกเลิกการเลือก
      setSelectedProfile(null);
    } else {
      // ถ้ากดรูปใหม่ ให้เลือกรูปนั้น
      setSelectedProfile(index);
    }
  };

  const handleNextButtonPress = () => {
    if (isNextButtonEnabled) {
      navigation.navigate('MedTime', { profileIndex: selectedProfile, username });
    } else {
      alert('กรุณาเลือกโปรไฟล์และตั้งชื่อ Username');
    }
  };

  const handleGoBack = () => {
    navigation.goBack();
  };

  return (
    <ImageBackground
      source={require('./assets/bg_med.jpg')} // กำหนดรูปภาพพื้นหลัง
      style={styles.background} // ใช้ style สำหรับพื้นหลัง
    >
      <TouchableOpacity style={styles.backButton} onPress={handleGoBack}>
        <Text style={styles.backButtonText}>&#10094;</Text>
      </TouchableOpacity>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Profile settings</Text>
        <Text style={styles.subtitle}>Choose a profile picture</Text>
        <View style={styles.profileContainer}>
          {profiles.map((profileImage, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.profileButton,
                selectedProfile === index && styles.selectedProfile,
              ]}
              onPress={() => handleProfileSelect(index)}
            >
              <Image source={profileImage} style={styles.profileImage} resizeMode="cover" />
            </TouchableOpacity>
          ))}
        </View>
        <Text style={styles.subtitle}>Username</Text>
        <TextInput
          style={styles.usernameInput}
          placeholder="Enter your username"
          value={username}
          onChangeText={setUsername}
        />
        <TouchableOpacity
          style={[styles.nextButton, !isNextButtonEnabled && styles.nextButtonDisabled]} // กำหนด style แบบมีเงื่อนไข
          onPress={handleNextButtonPress}
          disabled={!isNextButtonEnabled} // ควบคุมสถานะ disabled ของปุ่ม
        >
          <Text style={[styles.nextButtonText, isNextButtonEnabled && styles.nextButtonEnabledText]}>Next</Text>
        </TouchableOpacity>
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1, // ทำให้พื้นหลังเต็มหน้าจอ
    resizeMode: 'cover', // ปรับขนาดรูปภาพให้พอดีกับพื้นหลัง
    justifyContent: 'center', // จัดเนื้อหาให้อยู่ตรงกลาง (ตามแนวตั้ง)
    alignItems: 'center', // จัดเนื้อหาให้อยู่ตรงกลาง (ตามแนวนอน)
  },
  backButton: {
    position: 'absolute',
    top: 40,
    left: 20,
    paddingVertical: 10, // เพิ่ม padding ให้ปุ่มกดง่ายขึ้น
    paddingHorizontal: 15,
    borderRadius: 5,
    zIndex: 10, // ทำให้ปุ่มอยู่ด้านบนขององค์ประกอบอื่น
  },
  backButtonText: {
    color: '#333333',
    fontSize: 20,
    fontWeight: 'bold',
  },
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 60, // เพิ่ม paddingTop เพื่อให้มีพื้นที่ด้านบนสำหรับปุ่มย้อนกลับ
    paddingHorizontal: 20,
    width: '100%', // ทำให้ container กว้างเต็มหน้าจอเพื่อจัดกึ่งกลางเนื้อหา
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333', // ปรับสีข้อความให้เข้ากับพื้นหลัง (ถ้าจำเป็น)
  },
  subtitle: {
    fontSize: 18,
    marginBottom: 10,
    alignSelf: 'flex-start',
    color: '#333', // ปรับสีข้อความให้เข้ากับพื้นหลัง (ถ้าจำเป็น)
  },
  profileContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    marginBottom: 30,
  },
  profileButton: {
    width: 70,
    height: 70,
    borderRadius: 35,
    borderWidth: 2,
    borderColor: '#ccc',
    margin: 8,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedProfile: {
    borderColor: '#90EE90', // สีเขียวอ่อนเมื่อเลือก
    borderWidth: 3,
  },
  profileImage: {
    width: '100%',
    height: '100%',
  },
  usernameInput: {
    width: '100%',
    padding: 15,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 20,
    backgroundColor: 'white', // เพิ่มพื้นหลังสีขาวให้อ TextInput เพื่อให้อ่านง่ายขึ้น
  },
  nextButton: {
    backgroundColor: '#90EE90',
    padding: 15,
    borderRadius: 20,
    width: '100%',
    alignItems: 'center',
  },
  nextButtonDisabled: {
    backgroundColor: '#888', // สีเทาสำหรับปุ่มที่ยังไม่พร้อมใช้งาน
  },
  nextButtonText: {
    color: '#fff', // สีขาวเป็นค่าเริ่มต้นเมื่อปุ่มไม่ disabled
    fontSize: 18,
    fontWeight: 'bold',
  },
  nextButtonEnabledText: {
    color: '#333', // สีเทาเข้มเมื่อปุ่มพร้อมใช้งาน (สีเขียว)
  },
});

export default ProfileScreen;