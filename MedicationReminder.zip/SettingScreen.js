import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Image,
  Switch,
  ScrollView,
  Linking,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';

const SettingScreen = () => {
  const navigation = useNavigation();
  const { profileIndex: initialProfileIndex, username: initialUsername } = useRoute().params || {};
  const [isNotificationEnabled, setIsNotificationEnabled] = useState(false); // ค่าเริ่มต้นปิดแจ้งเตือน
  const [profileIndex, setProfileIndex] = useState(initialProfileIndex !== undefined ? initialProfileIndex : 0);
  const [username, setUsername] = useState(initialUsername !== undefined ? initialUsername : 'Guest');

  const profiles = [
    require('./assets/pm1.jpg'),
    require('./assets/pm2.jpg'),
    require('./assets/pm3.jpg'),
    require('./assets/pm4.jpg'),
    require('./assets/pm5.jpg'),
    require('./assets/pm6.png'),
  ];
  const selectedProfileImage = profiles[profileIndex];

  useEffect(() => {
    // ดึงค่าการตั้งค่า (เช่น สถานะแจ้งเตือน, ชื่อผู้ใช้) จาก AsyncStorage หรือ State ส่วนกลาง (ถ้ามี)
    // นี่เป็นตัวอย่างการตั้งค่าเริ่มต้น
    if (initialProfileIndex !== undefined) {
      setProfileIndex(initialProfileIndex);
    }
    if (initialUsername !== undefined) {
      setUsername(initialUsername);
    }
  }, [initialProfileIndex, initialUsername]);

  const handleNotificationToggle = () => {
    setIsNotificationEnabled(!isNotificationEnabled);
    // บันทึกสถานะการแจ้งเตือนไปยัง AsyncStorage หรือ State ส่วนกลาง (ถ้ามี)
  };

  const handleContactEmailPress = () => {
    Linking.openURL('mailto:6631503032@lamduan.mfu.ac.th'); // แทนที่ด้วยอีเมลของคุณ
  };

  const handleTwitterPress = () => {
    Linking.openURL('https://twitter.com/'); // แทนที่ด้วย Twitter ของคุณ
  };

  const handleGoBack = () => {
    navigation.goBack();
  };

  return (
    <ScrollView style={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={handleGoBack}>
        <Text style={styles.backButtonText}>&#10094;</Text>
      </TouchableOpacity>
      <Text style={styles.title}>Settings</Text>

      {/* ข้อมูลโปรไฟล์ */}
      <View style={styles.profileSection}>
        <View style={styles.profileImageContainer}>
          <Image source={selectedProfileImage} style={styles.profileImage} resizeMode="cover" />
        </View>
        <Text style={styles.usernameText}>{username}</Text>
      </View>

      {/* ตั้งค่าการแจ้งเตือน */}
      <View style={styles.settingItem}>
        <Text style={styles.settingLabel}>Notifications</Text>
        <Switch
          trackColor={{ false: '#767577', true: '#90EE90' }}
          thumbColor={isNotificationEnabled ? '#f4f3f4' : '#f4f3f4'}
          ios_backgroundColor="#3e3e3e"
          onValueChange={handleNotificationToggle}
          value={isNotificationEnabled}
        />
      </View>

      {/* ข้อมูลการติดต่อ */}
      <View style={styles.contactSection}>
        <Text style={styles.sectionTitle}>Contact Information</Text>
        <TouchableOpacity style={styles.contactItem} onPress={handleContactEmailPress}>
          <View style={styles.contactIcon}>
            {/* คุณสามารถใช้ไอคอน Email ที่นี่ */}
            <Text style={styles.iconText}>✉</Text>
          </View>
          <Text style={styles.contactText}>Contact Email</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.contactItem} onPress={handleTwitterPress}>
          <View style={styles.contactIcon}>
            {/* คุณสามารถใช้ไอคอน Twitter ที่นี่ */}
            <Text style={styles.iconText}>🐦</Text>
          </View>
          <Text style={styles.contactText}>Twitter</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f0f8ff',
  },
  backButton: {
    position: 'absolute',
    top: 40,
    left: 20,
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 5,
    zIndex: 10,
  },
  backButtonText: {
    color: '#333333',
    fontSize: 20,
    fontWeight: 'bold',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 30,
    marginTop: 60,
    color: '#333',
    textAlign: 'center',
  },
  profileSection: {
    alignItems: 'center',
    marginBottom: 30,
  },
  profileImageContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    overflow: 'hidden',
    marginBottom: 10,
    borderWidth: 2,
    borderColor: '#90EE90',
  },
  profileImage: {
    width: '100%',
    height: '100%',
  },
  usernameText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#555',
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  settingLabel: {
    fontSize: 16,
    color: '#333',
  },
  contactSection: {
    marginTop: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  contactItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  contactIcon: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#d3d3d3',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  iconText: {
    fontSize: 18,
    color: '#555',
  },
  contactText: {
    fontSize: 16,
    color: '#555',
  },
});

export default SettingScreen;